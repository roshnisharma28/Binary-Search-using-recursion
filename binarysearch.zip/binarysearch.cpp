#include<iostream>
using namespace std;
void print(int arr[],int start,int end){
    for(int i=start;i<=end;i++){
        cout<<arr[i]<<" ";
    }

}
bool binarysearch(int arr[],int start,int end,int key){

    //to see how it's working
    print(arr,start,end);
    cout<<endl<<endl;


    //base case
    if(start>end){
        return 0; 
    }
    int mid=start+(end-start)/2;
    cout<<"value of mid: "<<arr[mid]<<endl;

    if(arr[mid]==key){
        return 1;
    }
    if(arr[mid]>key){
        return binarysearch(arr,start,mid-1,key);
    }
    else{
        return binarysearch(arr,mid+1,end,key);
    }



}
int main(){
    int arr[8]={2,3,4,5,6,8,9,11};
    int size=8;
    int key=12;
    bool ans=binarysearch(arr,0,7,key);
    if(ans==1){
        cout<<"Key found"<<endl;
    }
    else{
        cout<<"Key not found"<<endl;
    }
}